-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Ott 26, 2020 alle 19:34
-- Versione del server: 10.4.14-MariaDB
-- Versione PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prog_3`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `accounts`
--

CREATE TABLE `accounts` (
  `id_account` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `fk_idrole` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `accounts`
--

INSERT INTO `accounts` (`id_account`, `email`, `password`, `name`, `lastname`, `version`, `fk_idrole`) VALUES
(1, 'root', 'root', 'admin', 'admin', 1, 1),
(2, 'francesco.brancato98@gmail.com', 'apritisesamo', 'francesco', 'brancato', 1, 2),
(10, 'robertoolivo@gmail.com', 'olivo1234', 'roberto', 'olivo', 1, 2),
(11, 'andreanucita@unime.it', 'programmazione3', 'Andrea', 'Nucita', 1, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `categories`
--

CREATE TABLE `categories` (
  `id_category` int(11) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `description` varchar(45) NOT NULL,
  `version` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `categories`
--

INSERT INTO `categories` (`id_category`, `code`, `description`, `version`) VALUES
(1, 'PIZZA', 'categoria per pizza e focaccia', 1),
(2, 'DRINK', 'categoria per bibite', 1),
(3, 'ROSTIC', 'categoria per rustici', 1),
(4, 'DOLCI', 'categoria per dolci', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `customers`
--

CREATE TABLE `customers` (
  `phone_number` bigint(20) NOT NULL,
  `version` int(11) DEFAULT 1,
  `id_account` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `customers`
--

INSERT INTO `customers` (`phone_number`, `version`, `id_account`) VALUES
(3331215796, 1, 2),
(3768273946, 1, 10),
(3277354628, 1, 11);

-- --------------------------------------------------------

--
-- Struttura della tabella `join_p_o`
--

CREATE TABLE `join_p_o` (
  `fk_idproducts_join` int(11) NOT NULL,
  `fk_idorders_join` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `join_p_o`
--

INSERT INTO `join_p_o` (`fk_idproducts_join`, `fk_idorders_join`) VALUES
(22, 12),
(26, 12),
(22, 12),
(26, 12),
(14, 12),
(14, 12),
(7, 28),
(16, 29),
(14, 29),
(13, 29),
(22, 29),
(22, 29),
(20, 35),
(17, 35),
(22, 35),
(22, 35),
(24, 35),
(1, 43),
(6, 43),
(7, 43),
(10, 43),
(13, 45),
(17, 45),
(22, 45),
(24, 45),
(1, 46),
(6, 46),
(11, 46),
(13, 46);

-- --------------------------------------------------------

--
-- Struttura della tabella `orders`
--

CREATE TABLE `orders` (
  `id_order` int(11) NOT NULL,
  `code` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `table_number` int(11) NOT NULL,
  `fk_customer_id_account` int(11) NOT NULL,
  `fk_restaurateur_id_account` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `orders`
--

INSERT INTO `orders` (`id_order`, `code`, `date`, `table_number`, `fk_customer_id_account`, `fk_restaurateur_id_account`) VALUES
(1, 'ORDER1', '2020-09-16', 12, 2, 1),
(2, 'ORDER2', '2020-10-01', 5, 2, 1),
(41, 'ORDER1603650821659', '2020-10-25', 13, 2, 1),
(42, 'ORDER1603650977238', '2020-10-25', 9, 2, 1),
(48, 'ORDER1603652607796', '2020-10-25', 8, 2, 1),
(58, 'ORDER1603653959977', '2020-10-25', 9, 2, 1),
(60, 'ORDER1603659527617', '2020-10-25', 3, 10, 1),
(61, 'ORDER1603726622982', '2020-10-26', 9, 2, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `orders_details`
--

CREATE TABLE `orders_details` (
  `id_order_details` int(11) NOT NULL,
  `time` time NOT NULL,
  `fk_order_idorder_details` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `orders_details`
--

INSERT INTO `orders_details` (`id_order_details`, `time`, `fk_order_idorder_details`) VALUES
(5, '21:39:31', 1),
(6, '20:33:31', 1),
(9, '19:40:45', 2),
(12, '17:10:19', 1),
(28, '19:33:41', 41),
(29, '19:36:17', 42),
(35, '20:03:27', 48),
(43, '20:26:00', 58),
(45, '21:58:47', 60),
(46, '16:37:03', 61);

-- --------------------------------------------------------

--
-- Struttura della tabella `products`
--

CREATE TABLE `products` (
  `id_product` int(11) NOT NULL,
  `code` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(150) NOT NULL,
  `price` float NOT NULL,
  `fk_idcategory` int(11) NOT NULL,
  `version` int(11) DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `img_src` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `products`
--

INSERT INTO `products` (`id_product`, `code`, `name`, `description`, `price`, `fk_idcategory`, `version`, `active`, `img_src`) VALUES
(1, 'PIZ1', 'Margherita', 'Pomodoro, mozzarella, basilico', 4, 1, 4, 1, 'assets/pizza-margherita.jpg'),
(2, 'PIZ2', 'Biancaneve', 'Mozzarella fior di latte DOC', 4, 1, 2, 0, 'assets/biancaneve.jpg'),
(3, 'PIZ3', 'Americana', 'Pomodoro, mozzarella, wurster e patatine fritte', 5.5, 1, 1, 0, 'assets/americana.jpg'),
(4, 'PIZ4', 'Norma', 'Pomodoro, mozzarella, melanzane e ricotta', 6.5, 1, 1, 0, 'assets/norma.jpg'),
(5, 'DRI1', 'Acqua Naturale', 'Acqua Naturale Fontalba 50cl', 0.8, 2, 1, 0, 'assets/ACQUA-FONTALBA-NATURALE-Cl.50.jpg'),
(6, 'DRI2', 'Coca Cola', 'Coca Cola in lattina da 33cl', 1.5, 2, 2, 1, 'assets/coca-cola.jpg'),
(7, 'DRI3', 'Birra dello Stretto', 'Birra dell stretto da 33cl', 2, 2, 1, 1, 'assets/birra-dello-stretto.jpg'),
(8, 'DRI4', 'Sprite', 'Sprite in lattnina da 33cl', 1.3, 2, 1, 1, 'assets/sprite.jpg'),
(9, 'ROS1', 'Patatine fritte', 'Patatine fritte McCain', 2, 3, 1, 1, 'assets/patatine-fritte.jpg'),
(10, 'ROS2', 'Pane fritto', 'Pasta della pizza fritta', 1.5, 3, 1, 1, 'assets/pane-fritto.jpg'),
(11, 'ROS3', 'Arancino', 'Arancino alla carne', 1.5, 3, 1, 1, 'assets/arancino.jpg'),
(12, 'ROS4', 'Fritto misto', 'Patatine, pane fritto, wurstel x2 persone', 6, 3, 1, 1, 'assets/fritto-misto.jpg'),
(13, 'DOL1', 'Cannolo', 'Cannolo alla ricotta con gocce di cioccolato', 3, 4, 1, 1, 'assets/cannolo.jpg'),
(14, 'DOL2', 'Tiramisù', 'Tiramisù al caffe', 3.5, 4, 1, 1, 'assets/tiramisu.jpg'),
(15, 'DOL3', 'Cheescake', 'Cheescake al cioccolato', 4, 4, 1, 1, 'assets/cheesecake-nutella.jpg'),
(16, 'DOL4', 'Crepes', 'Crepes alla nutella con zucchero a velo', 3.5, 4, 1, 1, 'assets/crepes-nutella.jpg'),
(17, 'PIZ5', 'Capricciosa', 'base margherita con cotto, funghi, würstel e carciofi', 6.5, 1, 1, 1, 'assets/capricciosa.jpg'),
(20, 'PIZBUF', 'Bufalina', 'Pomodoro, mozzarella di bufala e basilico', 7.5, 1, 0, 1, 'assets/bufalina.jpg'),
(22, 'ACQFR', 'Acqua frizzante', 'Acqua frizzante Fontalba 50cl', 0.8, 2, 0, 1, 'assets/ACQUA-FONTALBA-FRIZZANTE-Cl.50.jpg'),
(24, 'CROC', 'Crocchette', 'Crocchette di patate', 2.3, 3, 0, 1, 'assets/crocchette.jpg'),
(26, 'CAPR', 'Caprese', 'Mozzarella e pomodorini', 4.5, 1, 0, 0, 'assets/caprese.jpg'),
(27, 'TART', 'Tartufo', 'Tartufo al pistacchio di Bronte', 4.5, 4, 0, 0, 'assets/tartufo-pistacchio.jpg'),
(28, 'NUTPIZ', 'Pizza alla nutella', 'Pizza alla nutella con zucchero a velo e nocciole tostate', 5.5, 1, 0, 1, 'assets/nutella.jpg');

-- --------------------------------------------------------

--
-- Struttura della tabella `restaurateurs`
--

CREATE TABLE `restaurateurs` (
  `serial_number` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 0,
  `id_account` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `restaurateurs`
--

INSERT INTO `restaurateurs` (`serial_number`, `version`, `id_account`) VALUES
(1111, 1, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `roles`
--

CREATE TABLE `roles` (
  `id_role` int(11) NOT NULL,
  `description` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  `version` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `roles`
--

INSERT INTO `roles` (`id_role`, `description`, `code`, `version`) VALUES
(1, 'Ruolo per il ristoratore', 'REST', 1),
(2, 'Ruolo per il cliente', 'CUST', 1);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id_account`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `fk_account_role1_idx` (`fk_idrole`);

--
-- Indici per le tabelle `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_category`),
  ADD UNIQUE KEY `code_UNIQUE` (`code`);

--
-- Indici per le tabelle `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id_account`),
  ADD KEY `fk_customer_account1_idx` (`id_account`);

--
-- Indici per le tabelle `join_p_o`
--
ALTER TABLE `join_p_o`
  ADD KEY `fk_idproducts_join` (`fk_idproducts_join`) USING BTREE,
  ADD KEY `fk_idorders_join` (`fk_idorders_join`);

--
-- Indici per le tabelle `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `fk_reservation_customer1_idx` (`fk_customer_id_account`),
  ADD KEY `fk_restaurateur_id_account` (`fk_restaurateur_id_account`);

--
-- Indici per le tabelle `orders_details`
--
ALTER TABLE `orders_details`
  ADD PRIMARY KEY (`id_order_details`),
  ADD KEY `fk_order_idorder_details` (`fk_order_idorder_details`) USING BTREE;

--
-- Indici per le tabelle `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`),
  ADD UNIQUE KEY `code_UNIQUE` (`code`),
  ADD KEY `fk_product_category1_idx` (`fk_idcategory`);

--
-- Indici per le tabelle `restaurateurs`
--
ALTER TABLE `restaurateurs`
  ADD PRIMARY KEY (`id_account`),
  ADD UNIQUE KEY `serial_number_UNIQUE` (`serial_number`),
  ADD KEY `fk_restaurateur_account1_idx` (`id_account`);

--
-- Indici per le tabelle `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_role`),
  ADD UNIQUE KEY `code_UNIQUE` (`code`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id_account` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT per la tabella `categories`
--
ALTER TABLE `categories`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT per la tabella `orders_details`
--
ALTER TABLE `orders_details`
  MODIFY `id_order_details` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT per la tabella `products`
--
ALTER TABLE `products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT per la tabella `roles`
--
ALTER TABLE `roles`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `fk_account_role1` FOREIGN KEY (`fk_idrole`) REFERENCES `roles` (`id_role`);

--
-- Limiti per la tabella `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `fk_customer_account1` FOREIGN KEY (`id_account`) REFERENCES `accounts` (`id_account`);

--
-- Limiti per la tabella `join_p_o`
--
ALTER TABLE `join_p_o`
  ADD CONSTRAINT `join_p_o_ibfk_3` FOREIGN KEY (`fk_idproducts_join`) REFERENCES `products` (`id_product`),
  ADD CONSTRAINT `join_p_o_ibfk_7` FOREIGN KEY (`fk_idorders_join`) REFERENCES `orders_details` (`id_order_details`);

--
-- Limiti per la tabella `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_reservation_customer1` FOREIGN KEY (`fk_customer_id_account`) REFERENCES `customers` (`id_account`),
  ADD CONSTRAINT `fk_reservation_restaurateurs` FOREIGN KEY (`fk_restaurateur_id_account`) REFERENCES `restaurateurs` (`id_account`);

--
-- Limiti per la tabella `orders_details`
--
ALTER TABLE `orders_details`
  ADD CONSTRAINT `fk_order_idorder_details` FOREIGN KEY (`fk_order_idorder_details`) REFERENCES `orders` (`id_order`);

--
-- Limiti per la tabella `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_category1` FOREIGN KEY (`fk_idcategory`) REFERENCES `categories` (`id_category`);

--
-- Limiti per la tabella `restaurateurs`
--
ALTER TABLE `restaurateurs`
  ADD CONSTRAINT `fk_restaurateur_account1` FOREIGN KEY (`id_account`) REFERENCES `accounts` (`id_account`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
