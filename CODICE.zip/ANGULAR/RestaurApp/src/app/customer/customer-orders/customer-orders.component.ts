import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../api.service';
import {HttpClient} from '@angular/common/http';
import {Orders} from '../../order/model/orders';

/* Componente per lista degli ordini del cliente */

@Component({
  selector: 'app-customer-orders',
  templateUrl: './customer-orders.component.html',
  styleUrls: ['./customer-orders.component.css']
})
export class CustomerOrdersComponent implements OnInit {
  userOrders: Orders[];
  idLoggedUser: string;
  userOrdersList: string = 'http://localhost:8080/prog_3/myOrders.php?id=';
  constructor(private apiService: ApiService, private http: HttpClient) {
    this.idLoggedUser = JSON.parse(this.apiService.getToken()).id_account;
  }

  ngOnInit(): void {
    console.log(this.idLoggedUser);
    this.http.get(this.userOrdersList + this.idLoggedUser).
    subscribe((data: Orders[]) => {
      this.userOrders = data;
      console.log(this.userOrders);
    });
  }

}
