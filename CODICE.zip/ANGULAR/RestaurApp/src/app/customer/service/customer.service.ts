import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {CustomerOrder} from '../model/customer-order';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) {
  }

  public createOrder(customerOrder: CustomerOrder) {
    return this.http.post('http://localhost:8080/prog_3/newOrder.php', customerOrder, {responseType: 'text'});
  }

}
