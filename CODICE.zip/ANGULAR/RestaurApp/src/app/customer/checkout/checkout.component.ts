import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {CustomerOrder} from '../model/customer-order';
import {ApiService} from '../../api.service';
import {CustomerService} from '../service/customer.service';

/* Componente per evadere l'ordine */

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  items: any;
  cart: any[] = [];
  tableNumber: any;
  tabNum: any[] = [];
  finalCart: any[] = [];
  customerOrder: CustomerOrder = new CustomerOrder();
  constructor(private router: Router, private activatedRoute: ActivatedRoute, private apiServie: ApiService,
              private customerService: CustomerService) {
    this.customerOrder.idProducts = new Array();
  }

  ngOnInit(): void {
    this.printSelectedProducts();
    console.log(this.items);
  }

  // Stampa a schermo dei prodotti selezionati
  printSelectedProducts() {
    this.items = this.activatedRoute.snapshot.paramMap.get('carrello');
    this.items = this.cleanString(this.items);
    this.items = JSON.parse(this.items);
  }

  // Funzione per "pulire" la stringa dei prodotti
  cleanString(str) {
    str = str.replace('"[', '[');
    str = str.replace(']"', ']');
    return str;
  }

  // Funzione per ottenere il numero del tavolo
  getTableNumber() {
    // @ts-ignore
    this.tableNumber = document.getElementById('tableNumber').value;
    this.tabNum.push(this.tableNumber);
  }

  // Funzione per ottenere l'id dei prodotti
  getIdProducts() {
    let i;
    for (i = 0; i < this.items.length; i++) {
      this.customerOrder.idProducts.push(this.items[i].idProduct);
    }
  }

  // Conferma dell'ordine
  confirm() {
    this.cart = this.items.concat();
    this.getTableNumber();
    this.finalCart = this.cart.concat(this.tabNum);
    const tavolo = this.finalCart.pop();
    this.customerOrder.code = `ORDER` + Date.now();
    this.customerOrder.date = new Date().toISOString().split('T')[0];
    this.customerOrder.tableNumber = tavolo;
    this.customerOrder.idCustomer = this.apiServie.getLoggedUser().id_account;
    this.customerOrder.idRestaurateur = 1;
    this.getIdProducts();
    console.log(this.customerOrder);
    this.customerService.createOrder(this.customerOrder).subscribe(data => {
       alert('Ordine effettuato correttamente');
       this.router.navigateByUrl('myorders');
    });
  }
}
