export class CustomerOrder {
  code: string;
  date: any;
  tableNumber: number;
  idCustomer: number;
  idRestaurateur: number;
  idProducts: number[];
}
