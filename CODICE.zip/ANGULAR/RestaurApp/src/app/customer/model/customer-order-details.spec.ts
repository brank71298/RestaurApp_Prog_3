import { CustomerOrderDetails } from './customer-order-details';

describe('CustomerOrderDetails', () => {
  it('should create an instance', () => {
    expect(new CustomerOrderDetails()).toBeTruthy();
  });
});
