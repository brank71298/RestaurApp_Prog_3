export class CustomerOrderDetails {
  idCustomerOrder: number;
  time: any;
}
