
export class Cart {
  idProduct: number;
  nameProduct: string;
  priceProduct: number;
}
