import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ProductsService} from '../../products/service/products.service';
import {Products} from '../../products/model/products';
import {Cart} from '../model/cart';
import {Router} from '@angular/router';
import {Observable, observable, of} from 'rxjs';

@Component({
  selector: 'app-customer-products',
  templateUrl: './customer-products.component.html',
  styleUrls: ['./customer-products.component.css']
})
export class CustomerProductsComponent implements OnInit {
  products: Products[];
  cartItems: Cart[];
  constructor(private productsService: ProductsService, private router: Router) {
    this.cartItems = new Array();
  }

  ngOnInit(): void {
    this.productsService.getProducts().subscribe(
      (data: Products[]) => {
        this.products = data.filter((item) => item.active == 1);
      }
    );
  }

  // Aggiunta dei prodotti al carrello
  addToCart(product: Products) {
    this.cartItems.push({
      idProduct: product.idProduct,
      nameProduct: product.name,
      priceProduct: product.price
    });
  }

  // Funzione per andare alla pagina di checkout con i prodotti del carrello
  toCheckout(cart: Cart[]) {
    this.cartItems.forEach(value => cart.values());
    console.log(cart);
    this.router.navigate(['checkout', JSON.stringify(this.cartItems)]);
  }

}
