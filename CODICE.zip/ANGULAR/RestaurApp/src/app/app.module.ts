import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { ProductsComponent } from './products/all-products/products.component';
import { NavbarComponent } from './core/navbar/navbar.component';
import { HomeComponent } from './core/home/home.component';
import { NewProductComponent } from './products/new-product/new-product.component';
import {CommonModule} from '@angular/common';
import { EditProductComponent } from './products/edit-product/edit-product.component';
import { AllOrdersComponent } from './order/all-orders/all-orders.component';
import { OrderDetailsComponent } from './order/order-details/order-details.component';
import { DisactiveProductComponent } from './products/disactive-product/disactive-product.component';
import { CustomerProductsComponent } from './customer/customer-products/customer-products.component';
import { CustomerOrdersComponent } from './customer/customer-orders/customer-orders.component';
import { CheckoutComponent } from './customer/checkout/checkout.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {
  RoleGuardService as RoleGuard
} from './guards/role-guard.service';

const routes: Routes = [
  {path: 'myorders', component: CustomerOrdersComponent},
  {path: 'checkout/:carrello', component: CheckoutComponent},
  {path: 'disactived-products', component: DisactiveProductComponent, canActivate: [RoleGuard], data: {role: 1}},
  {path: 'menu', component: CustomerProductsComponent},
  {path: 'details/:id', component: OrderDetailsComponent},
  {path: 'orders', component: AllOrdersComponent, canActivate: [RoleGuard], data: {role: 1}},
  {path: 'edit/:id', component: EditProductComponent},
  {path: 'add-product', component: NewProductComponent},
  {path: 'actived-products', component: ProductsComponent, canActivate: [RoleGuard], data: {role: 1}},
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent},
  {path: 'registration', component: RegisterComponent}
];

@NgModule({
    declarations: [
        AppComponent,
        ProductsComponent,
        NavbarComponent,
        HomeComponent,
        NewProductComponent,
        EditProductComponent,
        AllOrdersComponent,
        OrderDetailsComponent,
        DisactiveProductComponent,
        CustomerProductsComponent,
        CustomerOrdersComponent,
        CheckoutComponent,
        LoginComponent,
        RegisterComponent
    ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ProductsComponent, RoleGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
