import { Injectable, Output, EventEmitter } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ApiService {
  redirectUrl: string;
  baseUrl: string = 'http://localhost:8080/prog_3';
  token: any;
  user: any;
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();

  constructor(private httpClient: HttpClient) { }

  // Autenticazione dell'utente
  public userlogin(email, password) {
    return this.httpClient.post<any>(this.baseUrl + '/login.php', { email, password })
      .pipe(map(Users => {
        this.setToken(this.token = JSON.stringify(Users[0]));
        this.getLoggedInName.emit(true);
        return Users;
      }));
  }

  // Invio dei dati del nuovo utente al db
  public userregistration(name, lastname, phone, email, pwd) {
    return this.httpClient.post<any>(this.baseUrl + '/register.php', { name, lastname, phone, email, pwd })
      .pipe(map(Users => {
        return Users;
      }));
  }

//token
  setToken(token: string) {
    localStorage.setItem('token', token);
  }
  getToken() {
    return localStorage.getItem('token');
  }
  deleteToken() {
    localStorage.removeItem('token');
  }

  // Verifica se l'utente è loggato o meno
  isLoggedIn() {
    const usertoken = this.getToken();
    if (usertoken != null) {
      return true;
    }
    return false;
  }
  cleanString(str) {
    str = str.replace('"[', '[');
    str = str.replace(']"', ']');
    return str;
  }
  getLoggedUser() {
    this.user = localStorage.getItem('token');
    return JSON.parse(this.user);
  }

}
