import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisactiveProductComponent } from './disactive-product.component';

describe('DisactiveProductComponent', () => {
  let component: DisactiveProductComponent;
  let fixture: ComponentFixture<DisactiveProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisactiveProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisactiveProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
