import {Component, OnInit } from '@angular/core';
import {Products} from '../model/products';
import {ProductsService} from '../service/products.service';
import {Router} from '@angular/router';
import {ProductsComponent} from '../all-products/products.component';


@Component({
  selector: 'app-disactive-product',
  templateUrl: './disactive-product.component.html',
  styleUrls: ['./disactive-product.component.css']
})
export class DisactiveProductComponent implements OnInit {
  products: Products[];
  id: number;
  constructor(private productService: ProductsService, private router: Router, private refreshProducts: ProductsComponent) {

  }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(
      (data: Products[]) => {
        this.products = data;
      }
    );
  }

  // Funzione per attivare un prodotto
  active(product: Products) {
    this.id = product.idProduct;
    this.productService.activeProduct(product).subscribe(
      () => {
        this.ngOnInit();
        this.refreshProducts.ngOnInit();
      }
    );
  }

}
