import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ProductsService} from '../service/products.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private productsService: ProductsService,
              private router: Router, private routes: ActivatedRoute) { }

  updateProductForm: FormGroup;

  ngOnInit(): void {
    const routeParams = this.routes.snapshot.params;
    console.log(routeParams.id);

    // Compilazione del form per la modifica del prodotto
    this.updateProductForm = this.formBuilder.group(
      {
        name: ['', Validators.required],
        code: ['', Validators.required],
        categories: ['', Validators.required],
        description: ['', Validators.required],
        idProduct: [routeParams.id],
        price: ['', Validators.required],
        version: [],
        active: []
      });

    this.productsService.getProductById(routeParams.id).subscribe(
      (data: any) => {
        this.updateProductForm.patchValue(data);
        console.log(data);
      }
    );
  }

  // Invio del prodotto modificato al database
  update(){
    this.productsService.updateProduct(this.updateProductForm.value).subscribe(() => {
      alert('Prodotto aggiornato correttamente');
      this.router.navigateByUrl('actived-products');
    },
      error => console.log(error));
  }
}
