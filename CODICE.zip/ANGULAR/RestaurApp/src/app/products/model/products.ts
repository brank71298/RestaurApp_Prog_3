export class Products {
  idProduct: number;
  code: string;
  name: string;
  description: string;
  price: number;
  fkIdCategory: number;
  version: number;
  active: any;
  imgSrc: string;
}
