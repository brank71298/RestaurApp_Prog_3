import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ProductsService} from '../service/products.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private productsService: ProductsService, private router: Router) { }

  addProductForm: FormGroup;
  ngOnInit(): void {

    // Funzione per associare i dati del form alle variabili
    this.addProductForm = this.formBuilder.group(
      {
        name: ['', Validators.required],
        code: ['', Validators.required],
        categories: ['', Validators.required],
        description: ['', Validators.required],
        price: ['', Validators.required]
    });
  }

  // Funzione per aggiungere il nuovo prodotto
  addProduct() {
 // console.log(this.addProductForm.value);
    this.productsService.createProduct(this.addProductForm.value).
    subscribe(data => {
      alert('Prodotto aggiunto correttamente');
      this.router.navigateByUrl('actived-products');
    });
  }
}
