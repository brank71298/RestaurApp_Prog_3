import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Products} from '../model/products';
import {DisactiveProductComponent} from '../disactive-product/disactive-product.component';
import {ProductsComponent} from '../all-products/products.component';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private routeParams: number;

  constructor(private http: HttpClient) { }

  public getProducts() {
    return this.http.get<Products[]>('http://localhost:8080/prog_3/list.php', {responseType: 'json'});
  }

  public createProduct(product: Products) {
  return this.http.post('http://localhost:8080/prog_3/createProduct.php', product, {responseType: 'text'});
  }

  public getProductById(id: number) {
    return this.http.get<Products[]>('http://localhost:8080/prog_3/getProductById.php?id=' + id);
  }

  public updateProduct(product: Products) {
    return this.http.put('http://localhost:8080/prog_3/updateProduct.php' + '?id=' + product.idProduct, product, {responseType: 'text'});
  }

  public disactiveProduct(product: Products) {
    return this.http.put('http://localhost:8080/prog_3/disactiveProduct.php?id=' + product.idProduct, product, {responseType: 'text'});
  }

  public activeProduct(product: Products) {
    return this.http.put('http://localhost:8080/prog_3/activeProduct.php?id=' + product.idProduct, product, {responseType: 'text'});
  }

}
