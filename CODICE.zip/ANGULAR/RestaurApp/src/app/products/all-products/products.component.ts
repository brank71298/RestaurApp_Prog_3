import {Component, OnInit} from '@angular/core';
import {ProductsService} from '../service/products.service';
import {Products} from '../model/products';
import {Router} from '@angular/router';

/* Componente per la visualizzazione di tutti prodotti */

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: Products[];
  id: any;
  constructor(private productService: ProductsService, private router: Router) {
  }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(
      (data: Products[]) => {
        this.products = data;
        console.log(this.products);
      }
    );
  }

  // Funzione per andare al componente "new-product"
  newProduct(): void  {
    const url = '/add-product';
    this.router.navigateByUrl(url);
  }

  // Funzione per andare al componente "edit-product"
  edit(products: Products) {
    this.id = products.idProduct;
    this.router.navigateByUrl('edit/' + this.id);

  }

  // Funzione per disattivare un prodotto
  disactive(product: Products) {
    this.id = product.idProduct;
    console.log(this.id);
    this.productService.disactiveProduct(product).subscribe(
      () => {
        this.ngOnInit();
      }
    );
  }

}
