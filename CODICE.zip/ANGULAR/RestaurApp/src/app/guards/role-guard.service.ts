import { Injectable } from '@angular/core';
import {Router, CanActivate} from '@angular/router';
import {ApiService} from '../api.service';


@Injectable()
export class RoleGuardService implements CanActivate {

  constructor(public apiService: ApiService, public router: Router) {
  }

  // Verifica sul ruolo dell'utente loggato
  canActivate(): boolean {

    const role = this.apiService.getLoggedUser().fk_idrole;

    if (!this.apiService.isLoggedIn() || role === '2') {
      alert('Non puoi accedere a questa pagina');
      return false;
    }
    return true;
  }
}
