export class Users {
  public Id: number;
  public name: string;
  public pwd: string;
  public email: string;
  public fkIdrole: number;

  constructor(Id: number, name: string, pwd: string, email: string, fkIdrole: number) {
    this.Id = Id;
    this.name = name;
    this.pwd = pwd;
    this.email = email;
    this.fkIdrole = fkIdrole;
  }
}
