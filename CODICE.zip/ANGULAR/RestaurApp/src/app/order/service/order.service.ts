import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Orders} from '../model/orders';
import {OrderDetails} from '../model/order-details';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  // Ottenimento ordini da db
  getOrders() {
    return this.http.get<Orders[]>('http://localhost:8080/prog_3/ordersList.php', {responseType: 'json'});
  }

  // Ottenimento dettagli ordine da db
  getOrderDetails(id: number) {
    return this.http.get<OrderDetails[]>('http://localhost:8080/prog_3/orderDetailsList.php?id=' + id, {responseType: 'json'});
  }
}
