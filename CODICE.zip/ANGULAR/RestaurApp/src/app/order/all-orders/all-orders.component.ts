import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {Orders} from '../model/orders';
import {OrderService} from '../service/order.service';

/* Componente per la visualizzazione di tutti gli ordini effettuati dai clienti */

@Component({
  selector: 'app-all-orders',
  templateUrl: './all-orders.component.html',
  styleUrls: ['./all-orders.component.css']
})
export class AllOrdersComponent implements OnInit {
  orders: Orders[];
  id: any;
  constructor(private orderService: OrderService, private router: Router) { }

  ngOnInit(): void {
    this.orderService.getOrders().subscribe(
      (data: Orders[]) => {
        this.orders = data;
        console.log(this.orders);
      }
    );
  }

  details(order: Orders) {
    this.id = order.idOrder;
    console.log(this.id);
    this.router.navigateByUrl('details/' + this.id);
  }

}
