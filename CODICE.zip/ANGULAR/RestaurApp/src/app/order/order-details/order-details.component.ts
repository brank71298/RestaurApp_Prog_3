import { Component, OnInit } from '@angular/core';
import {OrderService} from '../service/order.service';
import {ActivatedRoute, Router} from '@angular/router';
import {OrderDetails} from '../model/order-details';

/* Componente per la visualizzazione dei dettagli di un ordine */

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
  orderDetails: OrderDetails[];
  id: any;
  constructor(private orderService: OrderService, private router: Router, private routes: ActivatedRoute) { }

  ngOnInit(): void {
    const routeParams = this.routes.snapshot.params;
    console.log(routeParams.id);
    this.orderService.getOrderDetails(routeParams.id).subscribe(
      (data: any) => {
        this.orderDetails = data;
        console.log(this.orderDetails);
      }
    );
  }

}
