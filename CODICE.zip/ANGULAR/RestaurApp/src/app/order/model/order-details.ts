
export class OrderDetails {
  time: any;
  idProduct: number;
  nameProduct: string;
}
