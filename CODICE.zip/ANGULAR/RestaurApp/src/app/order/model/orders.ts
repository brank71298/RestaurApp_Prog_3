export class Orders {
  idOrder: number;
  code: string;
  date: Date;
  tableNumber: number;
}
