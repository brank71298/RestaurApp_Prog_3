import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../api.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  loginbtn: boolean;
  logoutbtn: boolean;

 // controllo su utente se ha effettuato o meno il login
  constructor(private dataService: ApiService, private router: Router) {
    dataService.getLoggedInName.subscribe(name => this.changeName(name));
    if (this.dataService.isLoggedIn()) {
      console.log('loggedin');
      this.loginbtn = false;
      this.logoutbtn = true;
      console.log(this.loginbtn);
      console.log(this.logoutbtn);
    } else {
      this.loginbtn = true;
      this.logoutbtn = false;
      console.log(this.loginbtn);
      console.log(this.logoutbtn);
    }
  }

  // cambio nome dei tasti login/logout
  private changeName(name: boolean): void {
    this.logoutbtn = name;
    this.loginbtn = !name;
  }

  // logout utente attraverso cancellazione token
  logout() {
    this.dataService.deleteToken();
    this.router.navigateByUrl('login');
    this.changeName(name);
  }

  ngOnInit(): void {

  }
}
