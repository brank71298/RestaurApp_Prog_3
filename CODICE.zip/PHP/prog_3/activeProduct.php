<?php
require 'connect.php';

	$postdata = file_get_contents("php://input");

	  $id = $_GET['id'];

	if (isset($postdata) && !empty($postdata)) {

		$request = json_decode($postdata);

		$sql = "UPDATE `products` SET `active` = 1 WHERE `id_product` = $id";

		$result = mysqli_query($con, $sql);

	if($result) {
		echo "Record added successfully.";
	} else {
		echo "ERROR: Could not able to execute $sql. ";
		mysqli_error($con);
	}
}