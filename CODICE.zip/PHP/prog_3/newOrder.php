<?php
require 'connect.php';

	$postdata = file_get_contents("php://input");

	if (isset($postdata) && !empty($postdata)) {

		$request = json_decode($postdata);
		
		$code = mysqli_real_escape_string($con, trim($request->code));
		$date = mysqli_real_escape_string($con, trim($request->date));
		$tableNumber = mysqli_real_escape_string($con, trim($request->tableNumber));
		$idCustomer = mysqli_real_escape_string($con, trim($request->idCustomer));
		$idRestaurateur = mysqli_real_escape_string($con, trim($request->idRestaurateur));

		$sql = "INSERT INTO `orders` (`code`, `date`, `table_number`, `fk_customer_id_account`, `fk_restaurateur_id_account`) VALUES ('$code', '$date', '$tableNumber', '$idCustomer', '$idRestaurateur')";

		if(mysqli_query($con, $sql)) {
			echo "Record added successfully.";
		} else {
			error_reporting();
		}

		$fkIdOrder = mysqli_insert_id($con);
		$time = date("H:i:s");

		$sql = "INSERT INTO `orders_details` (`time`, `fk_order_idorder_details`) VALUES ('$time', '$fkIdOrder')";

		if(mysqli_query($con, $sql)) {
			echo "Record added successfully.";
		} else {
			error_reporting();
		}

		$fkIdOrderDetails = mysqli_insert_id($con);

		$idProducts = ($request->idProducts);

		foreach ($idProducts as $idProducts => $idProduct) {

			$query = "INSERT INTO `join_p_o` (`fk_idproducts_join`, `fk_idorders_join`) VALUES ('$idProduct', '$fkIdOrderDetails')";

			if(mysqli_query($con, $query)) {
				echo "Hai aggiunto i prodotti";
			} else {
				error_reporting();
			}
		}

	}