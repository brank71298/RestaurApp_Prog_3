<?php
require 'connect.php';

	$postdata = file_get_contents("php://input");
	
	if(isset($postdata) && !empty($postdata)) {

		$request = json_decode($postdata);
		$name = trim($request->name);
		$pwd = mysqli_real_escape_string($con, trim($request->pwd));
		$email = mysqli_real_escape_string($con, trim($request->email));
		$lastname = mysqli_real_escape_string($con, trim($request->lastname));
		$phone = mysqli_real_escape_string($con, trim($request->phone));
		$fkIdRole = 2;

		$sql = "INSERT INTO accounts (name, password, email, lastname, fk_idrole) VALUES ('{$name}','{$pwd}','{$email}','{$lastname}', '{$fkIdRole}')";
		
		if(mysqli_query($con, $sql)) {
			echo "Record added successfully.";
		} else {
			error_reporting();
		}

		$idAccount = mysqli_insert_id($con);

		$sql = "INSERT INTO `customers` (`phone_number`, `id_account`) VALUES ('$phone', '$idAccount')";

		if(mysqli_query($con, $sql)) {
			echo "Record added successfully.";
		} else {
			error_reporting();
		}
	}
/*
	if ($con->query($sql) === TRUE) {
	$authdata = [
	'name' => $name,
	'pwd' => '',
	'email' => $email,
	'Id' => mysqli_insert_id($con)
	];
	echo json_encode($authdata);
	}
	}

	?>
*/