<?php

require 'connect.php';

  $id = $_GET['id'];

  $sql = "UPDATE `products` SET `active` = 0 WHERE `id_product` = $id";

	$result = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($result);

	echo $json = json_encode($row);

exit;