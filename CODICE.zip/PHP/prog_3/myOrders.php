	
<?php
require 'connect.php';
error_reporting(E_ERROR);
$id = $_GET['id'];
$orders = [];
$sql = $sql = "SELECT * FROM `orders`, `orders_details` WHERE `fk_customer_id_account` = {$id} and `fk_order_idorder_details` = `id_order`";

if ($result = mysqli_query($con,$sql)) {
	$cr = 0;
	while ($row = mysqli_fetch_assoc($result)) {
		$orders[$cr]['idOrder'] = $row['id_order'];
		$orders[$cr]['code'] = $row['code'];
		$orders[$cr]['date'] = $row['date'];
		$orders[$cr]['tableNumber'] = $row['table_number'];
		$orders[$cr]['time'] = $row['time'];
		$cr++;
	}

	echo json_encode($orders);
}
else {
	http_response_code(404);
}

?>