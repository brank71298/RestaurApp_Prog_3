	
<?php
require 'connect.php';
error_reporting(E_ERROR);
$products = [];
$sql = "SELECT * FROM `join_p_o` WHERE `fk_idorders_join` = 1 ";

if ($result = mysqli_query($con,$sql)) {
	$cr = 0;
	while ($row = mysqli_fetch_assoc($result)) {
		$products[$cr]['idProductsJoin'] = $row['fk_idproducts_join'];
/*		$products[$cr]['pCode'] = $row['code'];
		$products[$cr]['pName'] = $row['name'];
		$products[$cr]['pDesc'] = $row['description'];
		$products[$cr]['pPrice'] = $row['price'];
		$products[$cr]['pIdCat'] = $row['fk_idcategory'];
		$products[$cr]['pVer'] = $row['version'];
*/
		$cr++;
	}

	print_r($products);
}
else {
	http_response_code(404);
}

?>
