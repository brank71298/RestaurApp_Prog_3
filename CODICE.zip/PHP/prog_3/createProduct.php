<?php
require 'connect.php';

	$postdata = file_get_contents("php://input");

	if (isset($postdata) && !empty($postdata)) {

		$request = json_decode($postdata);
		
		$code = mysqli_real_escape_string($con, trim($request->code));
		$name = mysqli_real_escape_string($con, trim($request->name));
		$description = mysqli_real_escape_string($con, trim($request->description));
		$price = mysqli_real_escape_string($con, trim($request->price));
		$categories = mysqli_real_escape_string($con, trim($request->categories));

		$sql = "INSERT INTO `products` (`code`, `name`,  `description`, `price`, `fk_idCategory`) VALUES ( '{$code}', '{$name}', '{$description}', '{$price}', '{$categories}')";
	}

	if(mysqli_query($con,$sql)) {

		echo "Record added successfully.";
	} else {
		echo "ERROR: Could not able to execute $sql. ";
		mysqli_error($con);
	}