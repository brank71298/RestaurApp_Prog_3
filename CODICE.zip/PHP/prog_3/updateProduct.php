<?php
require 'connect.php';

	$postdata = file_get_contents("php://input");

	//$idProduct = $_GET['idProduct'];

	if (isset($postdata) && !empty($postdata)) {

		$request = json_decode($postdata);
		
		$idProduct = mysqli_real_escape_string($con, trim($request->idProduct));
		$code = mysqli_real_escape_string($con, trim($request->code));
		$name = mysqli_real_escape_string($con, trim($request->name));
		$description = mysqli_real_escape_string($con, trim($request->description));
		$price = mysqli_real_escape_string($con, trim($request->price));
		$categories = mysqli_real_escape_string($con, trim($request->categories));
		$version = mysqli_real_escape_string($con, trim($request->version));
		$active = mysqli_real_escape_string($con, trim($request->active));

		$version += $version;

		$sql = "UPDATE `products` SET `code` = '$code', `name` = '$name', `description` = '$description', `price` = '$price', `fk_idcategory` = '$categories', `version` = '$version', `active` = '$active' WHERE `id_product` = '{$idProduct}'";

	if(mysqli_query($con,$sql)) {

		echo "Record added successfully.";
	} else {
		echo "ERROR: Could not able to execute $sql. ";
		mysqli_error($con);
	}
}