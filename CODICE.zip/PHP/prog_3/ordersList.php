	
<?php
require 'connect.php';
error_reporting(E_ERROR);
$orders = [];
$sql = "SELECT * FROM orders";

if ($result = mysqli_query($con,$sql)) {
	$cr = 0;
	while ($row = mysqli_fetch_assoc($result)) {
		$orders[$cr]['idOrder'] = $row['id_order'];
		$orders[$cr]['code'] = $row['code'];
		$orders[$cr]['date'] = $row['date'];
		$orders[$cr]['tableNumber'] = $row['table_number'];
		$orders[$cr]['fkCustomerIdAccount'] = $row['fk_customer_id_account'];
		$orders[$cr]['version'] = $row['version'];
		$orders[$cr]['fkRestaurateurIdAccount'] = $row['fk_restaurateur_id_account'];
		$cr++;
	}

	echo json_encode($orders);
}
else {
	http_response_code(404);
}

?>
