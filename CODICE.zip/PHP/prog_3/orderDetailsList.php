	
<?php
require 'connect.php';
error_reporting(E_ERROR);
$id = $_GET['id'];
$orderDetails = [];
$sql = "SELECT * FROM `orders_details`, `products`, `join_p_o` WHERE `orders_details`.`fk_order_idorder_details`= $id AND `orders_details`.`id_order_details` = `join_p_o`.`fk_idorders_join` AND `join_p_o`.`fk_idproducts_join` = `products`.`id_product`";

if ($result = mysqli_query($con,$sql)) {
	$cr = 0;
	while ($row = mysqli_fetch_assoc($result)) {

		$orderDetails[$cr]['time'] = $row['time'];
		$orderDetails[$cr]['idProduct'] = $row['id_product'];
		$orderDetails[$cr]['nameProduct'] = $row['name'];
		$cr++;
	//	$orderDetails[$cr]['idOrderDetails'] = $row['id_order_details'];
	//	$orderDetails[$cr]['fkOrderIdOrderDetails'] = $row['fk_order_idorder_details'];
	//	$orderDetails[$cr]['fkJoinIdProduct'] = $row['fk_join_idproduct'];
	//	$orderDetails[$cr]['version'] = $row['version'];

	}

	echo json_encode($orderDetails);

}
else {
	error_reporting();
}

?>
