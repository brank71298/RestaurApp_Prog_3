	
<?php
require 'connect.php';
error_reporting(E_ERROR);
$products = [];
$sql = "SELECT * FROM products";

if ($result = mysqli_query($con,$sql)) {
	$cr = 0;
	while ($row = mysqli_fetch_assoc($result)) {
		$products[$cr]['idProduct'] = $row['id_product'];
		$products[$cr]['code'] = $row['code'];
		$products[$cr]['name'] = $row['name'];
		$products[$cr]['description'] = $row['description'];
		$products[$cr]['price'] = $row['price'];
		$products[$cr]['fkIdCategory'] = $row['fk_idcategory'];
		$products[$cr]['version'] = $row['version'];
		$products[$cr]['active'] = $row['active'];
		$products[$cr]['imgSrc'] = $row['img_src'];
		$cr++;
	}

	echo json_encode($products);
}
else {
	http_response_code(404);
}

?>
